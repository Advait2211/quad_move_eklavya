# Changelog – Unitree Go2 Description

All notable changes to this model will be documented in this file.

## [2025-02-16]
- Make actuator order match joint order.

## [2024-06-01]
- Fix foot solimp.

## [2023-10-23]
- Initial release.
